package com.springboot.phase3.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;

@Entity
@Table(name = "applynow")
public class Applynow {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "company_name")                        
	private String companyName;

	@Column(name = "full_name")                        
	private String fullName;
	@Column(name = "email_id")                        
	private String emailId;
	
	@Column(name = "phone_number")                        
	private  String phoneNumber;
	
	@Column(name = "address")                        
	private String address;
	
	public Applynow() {
		
	}
	public long getId() {                              
		return id;
	}
	public void setId(long id) {                    
		this.id = id;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getcompanyName() {                    
		return companyName;
	}
	public void setcompanyName(String companyName) {         
		this.companyName = companyName;
	}
	public String getFullName() {                       
		return fullName;
	}
	public void setFullName(String fullName) {          
		this.fullName = fullName;
	}
	
		public String getAddress() {                       
		return address;
	}
	public void setAddress(String address) {          
		this.address = address;
}
}