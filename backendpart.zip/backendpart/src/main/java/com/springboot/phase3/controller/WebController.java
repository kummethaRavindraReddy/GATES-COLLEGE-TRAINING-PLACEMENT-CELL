package com.springboot.phase3.controller;


import java.util.HashMap;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.phase3.model.Applynow;
import com.springboot.phase3.model.Student;
import com.springboot.phase3.repo.ApplynowRepository;
import com.springboot.phase3.repo.StudentRepository;
import com.springboot.phase3.rnf.ResourceNotFound;

@RestController
@CrossOrigin(origins = "http://localhost:4200")                

@RequestMapping("/api")
public class WebController {

	@Autowired
	private StudentRepository studentRepository;
	@Autowired
	private ApplynowRepository applynowRepository;
	
	
	// get all students
	@GetMapping("/students")
	public List<Student> getAllStudents(){
		return studentRepository.findAll();
	}		
	
	// create student rest api
	@PostMapping("/save-student")
	public Student createStudent(@RequestBody Student student) {
		return studentRepository.save(student);
	}
	
	
	
	@GetMapping("/applynow")
	public List<Applynow> getAllApplynows(){
		return applynowRepository.findAll();
	}		
	
	// create applynow rest api
	@PostMapping("/save-applynow")
	public Applynow createApplynow(@RequestBody Applynow applynow) {
	
		return applynowRepository.save(applynow);
	}
	
	
	
	// get student by id rest api
	@GetMapping("/students/{id}")
	public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
		Student student = studentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFound("Student not exist with id :" + id));
		return ResponseEntity.ok(student);
	}
	@GetMapping("/applynow/{id}")
	public ResponseEntity<Applynow> getapplynowById(@PathVariable Long id) {
		Applynow applynow = applynowRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFound("applynow not exist with id :" + id));
		return ResponseEntity.ok(applynow);
	}
	
	
	

	
	// update student rest api
	
	@PutMapping("/students/{id}")
	public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody Student studentDetails){
		Student student = studentRepository.findById(id)
				.orElseThrow();
		
		student.setFirstName(studentDetails.getFirstName());
		student.setLastName(studentDetails.getLastName());
		student.setEmailId(studentDetails.getEmailId());
		
		Student updatedStudent = studentRepository.save(student);
		return ResponseEntity.ok(updatedStudent);
	}
	
	//update applynow rest api
	
	@PutMapping("/applynow/{id}")
	public ResponseEntity<Applynow> createapplying(@PathVariable Long id, @RequestBody Applynow applynowDetails){
	
		Applynow applynow = applynowRepository.findById(id)
				.orElseThrow();
		applynow.setcompanyName(applynowDetails.getcompanyName());
		applynow.setFullName(applynowDetails.getFullName());
		
		applynow.setPhoneNumber(applynowDetails.getPhoneNumber());
		applynow.setAddress(applynowDetails.getAddress());
		
		Applynow updatedApplynow =  applynowRepository.save(applynow);
		return ResponseEntity.ok(updatedApplynow);
	}
	
	
	
	
	
	// delete student rest api
	@DeleteMapping("/students/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteStudent(@PathVariable Long id){
		Student student = studentRepository.findById(id)
				.orElseThrow();
		
		studentRepository.delete(student);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	
	@DeleteMapping("/applynow/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteApplynow(@PathVariable Long id){
		Applynow applynow =  applynowRepository.findById(id)
				.orElseThrow();
		
		applynowRepository.delete(applynow);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
}
